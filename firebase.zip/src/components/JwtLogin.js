import React from 'react'
import axios from 'axios'
import { withSignIn } from 'react-auth-kit'
import { link } from 'react-router-dom'

class signInComponent extends React.Component {
    state={email: '', password: ''}

    onSubmit = (e) => {
        e.preventDefault()
        axios.post('/api/login', this.state)
            .then((res)=>{
                if(res.status === 200){
                    if(this.props.signIn({
                        auth: {
                            token: 'ey....mA',
                            type: 'Bearer'
                        },
                        refresh: 'ey....mA',
                        userState: {
                            name: 'React User',
                            uid: 123456
                        }
                    })){
                        <link to={"./home"} />
                    }else {
                        //Throw error
                    }
                }
            })
    }

    render(){
        return (
            <form>
                <input type={"email"} onChange={(e)=>this.setState({...this.state, email: e.target.value})}/>
                <input type={"password"} onChange={(e)=>this.setState({...this.state, password: e.target.value})}/>
             
                <button>Submit</button>
            </form>
        )
    }
}

export default signInComponent;