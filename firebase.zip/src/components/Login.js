import React, {useState}  from 'react'
import { useSelector } from "react-redux"
import {useNavigate} from "react-router-dom"
import { useDispatch } from "react-redux";
import {store} from "../utils/store"
import {setUserName} from "../utils/userSlice"
import axios from 'axios';
import {  createUserWithEmailAndPassword  } from 'firebase/auth';
import { auth } from '../firebase';

const Login = () => {

const [username, setUsername] = useState('');
const [password, setPassword] = useState('');
const navigate = useNavigate();
const dispatch = useDispatch();
const userVal = useSelector(setUserName);
console.log("userval", userVal);
const handleLoginClick = async (e) => {
    e.preventDefault();
    dispatch(setUserName(username));
    await createUserWithEmailAndPassword(auth, username, password)
    .then((userCredential) => {
        // Signed in
        const user = userCredential.user;
        console.log(user);
        navigate("/login")
        // ...
    })
    .catch((error) => {
        const errorCode = error.code;
        const errorMessage = error.message;
        console.log(errorCode, errorMessage);
        // ..
    });
    navigate('/');
}

    return (
        <>
        
        <div> Hello User</div>
    <div className='h-screen flex flex-col  
    items-center justify-center'>
        <form >
          <input
            className='"text-sm text-gray-base w-full  
          mr-3 py-5 px-4 h-2 border  
          border-gray-200 rounded mb-2"'
            value={username}
            type="text"
            placeholder="Username"
            onChange={(e) => setUsername(e.target.value)}
          />
         <input
         className='text-sm text-gray-base w-full mr-3  
         py-5 px-4 h-2 border border-gray-200  
         rounded mb-2'
            value={password}
            type="password"
            placeholder="Password"
            onChange={(e) => setPassword(e.target.value)}
          />
          <button className='bg-green-400 w-full mt-4' onClick={handleLoginClick} type="submit">Login</button>
        </form>
    </div>
    </>
  )
}

export default Login