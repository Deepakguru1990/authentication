import useFetch from "react-fetch-hook";
import {useSelector} from 'react-redux'
import {setUserName} from "../utils/userSlice"

const Home = () => {
  const { data: posts, isLoading, error } = useFetch('https://jsonplaceholder.typicode.com/posts');
  const userName = useSelector(setUserName);

 console.log(userName);
  // Show a loading message while data is fetching
  if (isLoading) {
    return <h2>Loading...</h2>;
  }

  // Handle error
  if (error) {
    return <div className="error">Error: error fetching</div>;
  }

  return (
    <>

<div> Hello  {userName.payload.user.name}</div>
    <h1 className='font-bold text-3xl my-5 py-5 m-auto justify-center align-middle'>Post of users</h1>
    
    <div className="flex flex-wrap justify-center">
      {posts.map((post) => (
        <div key={post.id} className="my-5 pf-5 block max-w-sm p-6 bg-white border border-gray-200 rounded-lg shadow hover:bg-gray-100 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
          <h2 className='mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white'>{post.title}</h2>
          <p className="font-normal text-gray-700 dark:text-gray-400">{post.body}</p>
        </div>
      ))}
    </div>
    
    </>
  );
};

export default Home;
