
import './App.css';
import Homepage from "./components/Homepage"
import Login from "./components/Login"
import JwtLogin from './components/JwtLogin';
import { Routes, Route } from "react-router-dom";

function App() {
  return (
    <div className="">
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/jwtlogin" element={<JwtLogin />} />
      </Routes>
    </div>
  );
}

export default App;
