import { createSlice } from '@reduxjs/toolkit'

export const userSlice = createSlice({
    name: 'user',
    initialState: { user: '', age: 20 },
    reducers: {
      setUserName: (state, action) => {
        state.name = action.payload // mutate the state all you want with immer
      },
    },
})

export const { setUserName } = userSlice.actions;
export const selectUser = (state) => state.user.user;
export default userSlice.reducer;